import './styles.scss'
import World from './World'

new World()
